import requests
from datetime import datetime, timezone
from django.shortcuts import render
from django.conf import settings
from django.core.cache import cache
from .models import City
from .forms import CitySearchForm

class WeatherAPIError(Exception):
    pass

def get_weather_data_from_api(city_name):
    try:
        url = settings.OPENWEATHER_BASE_URL
        params = {
            'q': city_name,
            'appid': settings.OPENWEATHER_API_KEY,
            'units': 'metric'
        }
        response = requests.get(url, params=params, timeout=5)
        response.raise_for_status()
        data = response.json()
        if response.status_code != 200:
            raise WeatherAPIError(f"API returned status code {response.status_code}")
        return data
    except Exception:
        raise WeatherAPIError("Could not fetch weather data for this city.")

def process_weather_data(api_data):
    weather_info = {
        'city_name': api_data['name'],
        'country_code': api_data['sys']['country'],
        'latitude': api_data['coord']['lat'],
        'longitude': api_data['coord']['lon'],
        'temperature': round(api_data['main']['temp'], 1),
        'feels_like': round(api_data['main']['feels_like'], 1),
        'temp_min': round(api_data['main']['temp_min'], 1),
        'temp_max': round(api_data['main']['temp_max'], 1),
        'pressure': api_data['main']['pressure'],
        'humidity': api_data['main']['humidity'],
        'weather_main': api_data['weather'][0]['main'],
        'weather_description': api_data['weather'][0]['description'].title(),
        'weather_icon': api_data['weather'][0]['icon'],
        'wind_speed': round(api_data['wind']['speed'] * 3.6, 1),
        'wind_direction': api_data['wind'].get('deg', 0),
        'clouds': api_data['clouds']['all'],
        'visibility': api_data.get('visibility', 10000) // 1000,
        'sunrise': datetime.fromtimestamp(api_data['sys']['sunrise'], tz=timezone.utc),
        'sunset': datetime.fromtimestamp(api_data['sys']['sunset'], tz=timezone.utc),
        'timezone_offset': api_data['timezone'],
        'icon_url': f"http://openweathermap.org/img/wn/{api_data['weather'][0]['icon']}@2x.png"
    }
    return weather_info

def get_cached_or_fetch_weather(city_name):
    cache_key = f"weather_{city_name.lower().strip()}"
    cached_weather = cache.get(cache_key)
    if cached_weather:
        return cached_weather
    api_data = get_weather_data_from_api(city_name)
    weather_info = process_weather_data(api_data)
    cache.set(cache_key, weather_info, 900)
    return weather_info

def index(request):
    weather_data = None
    error_message = None
    form = CitySearchForm()
    if request.method == 'POST':
        form = CitySearchForm(request.POST)
        if form.is_valid():
            city_name = form.cleaned_data['city_name']
            try:
                weather_data = get_cached_or_fetch_weather(city_name)
            except WeatherAPIError as e:
                error_message = str(e)
            except Exception:
                error_message = "An unexpected error occurred. Please try again."
    context = {
        'form': form,
        'weather_data': weather_data,
        'error_message': error_message,
    }
    return render(request, 'weather/index.html', context)
