from django import forms
from django.core.validators import RegexValidator

class CitySearchForm(forms.Form):
    """Form for searching weather by city name"""
    city_name = forms.CharField(
        max_length=100,
        required=True,
        validators=[
            RegexValidator(
                regex=r'^[a-zA-Z\s\-]+$',
                message='City name should only contain letters, spaces, and hyphens.',
                code='invalid_city_name'
            )
        ],
        widget=forms.TextInput(attrs={
            'class': 'form-control form-control-lg',
            'placeholder': 'Enter city name (e.g., London, New York, Mumbai)',
            'autofocus': True,
            'autocomplete': 'off',
            'id': 'cityInput'
        }),
        label='',
        error_messages={
            'required': 'Please enter a city name.',
            'max_length': 'City name is too long.'
        }
    )

    def clean_city_name(self):
        city_name = self.cleaned_data.get('city_name', '')
        city_name = city_name.strip()
        if len(city_name) < 2:
            raise forms.ValidationError('City name must be at least 2 characters long.')
        return city_name
